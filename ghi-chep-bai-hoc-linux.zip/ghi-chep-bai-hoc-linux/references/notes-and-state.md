# Transcript toàn bài, sổ trạng thái và tóm tắt

## Nhận việc

Mặc định recorded_review: Hermes tự xem bản ghi, được phát/dừng, tua,
đổi tốc độ và mở lại bài để xử lý đủ. Giữ vị trí/playback của người dùng
chỉ khi họ yêu cầu live_together riêng. Không hỏi lại dữ liệu đã có.
Mỗi bài một thư mục. Tạo transcript và trạng thái ngay, không chờ cuối
buổi nhớ lại. Không sửa sources/, không ghi token/cookie hoặc URL chứa bí mật.

## Lưu lời trước

- Giữ raw TXT/SRT từng đoạn không chỉnh sửa. Lưu chỉ mục raw_sources:
  đường dẫn cục bộ, audio gốc, trạng thái nhận dạng, offset gốc biết được,
  playback_session_id, mốc tương đối và độ chắc ánh xạ.
- transcript-toan-bai.txt giữ toàn bộ lời đọc được theo timeline bản ghi,
  có nhãn chương/mốc và nguồn. Không thay lời bằng ý chính. Dấu câu/lỗi máy
  chỉ sửa trong bản đọc khi đã đối chiếu, raw còn nguyên. Chưa chắc để nhãn;
  thiếu lời ghi khoảng thiếu. Slide không cho phép tự dựng lời chưa nghe.
- Ghi người nói khi đủ bằng chứng. Không coi Whisper tự phân vai. Người
  chưa rõ ghi nhãn; chữ trên slide và mô tả thao tác không lời tách riêng.
- Ghép theo video_start/end hoặc offset file gốc đã xác minh, không theo
  thứ tự tua. Replay một khoảng thì so mốc và nội dung rồi chọn/ghép bản
  rõ hơn; ghi nguồn đã thay thế, không xóa raw. Cùng câu nói ở mốc khác có
  thể là thầy nhắc lại thật, không được xóa chỉ vì giống chữ.
- SRT tổng chỉ tạo khi có ánh xạ về bản gốc đủ tin cậy, thứ tự mốc hợp lệ.
  Nếu chưa khớp, bàn giao SRT từng đoạn cùng bảng offset và nhãn ước lượng.
  Không gán giờ đồng hồ hoặc CSV audio làm timecode video.

## Sổ trạng thái

trang-thai.json tối thiểu gồm:

- lesson_url hoặc source_file (không chứa thông tin đăng nhập), source_duration_seconds
  nếu biết, mode, updated_at, transcript_path, summary_path.
- raw_sources; playback_sessions; last_video_time_seconds; last_entry_id;
  last_image; last_processed_audio_chunk.
- observed_intervals (đã thấy/nghe), covered_intervals (đã chép đủ lời tương
  ứng), gaps (đầu/cuối, thiếu gì, lý do, độ chắc mốc, đã khôi phục chưa).
- caption_status, audio_source, recording_active, capture_ledger,
  recognition_status, technical_attempts, permission_evidence (phạm vi
  đồng ý thật, không bí mật).
- transcript_complete; summary_status (not_started/draft/final);
  complete. Không complete=true khi mới xong transcript hoặc còn thiếu.

Mỗi playback_sessions có id, source, capture_output, video_start_seconds,
video_end_seconds, playback_rate, audio_offset_seconds, mapping_confidence,
seek_or_rate_change, reason_started và reason_ended. Không đọc được thì
null kèm lý do, không đoán. Với file cục bộ, dùng offset trích file gốc đã
biết; không cần mô phỏng tốc độ player.

Sau tua/đổi tốc độ/mở lại phải có lượt playback mới và output mới, kiểm tra
vị trí/tốc độ thật. Nếu chỉ ước lượng video_start + audio_offset × rate,
phải có bằng chứng tốc độ không đổi/không buffering và ghi độ chắc. Phần
không đủ bằng chứng vẫn để mốc chưa khớp. Không công nhận đủ chỉ nhờ mốc
đầu/cuối trong khi đoạn giữa không nhận dạng được.

Trên Linux, đọc pipeline-status.json và capture-ledger.jsonl ở output,
segments/segments.csv và WAV, status.json trong transcript_audio_*.
phase=decoded chưa chứng minh đúng chữ, đã ghép transcript hay đã tóm tắt.

## Xử lý phần thiếu và tiếp tục

- Mất nguồn hoặc backlog: lưu điểm cuối, dừng thu và player khi có thể,
  xử lý audio đã đóng; quay lại điểm chưa xử lý cùng chút ngữ cảnh trước.
  Output mới, kiểm tra lại luồng. Không tự xóa STOP của người dùng.
- Nội bộ Hermes pause để ghi/đợi nhận dạng thì được tiếp tục trong nhiệm
  vụ. Người dùng bảo pause/dừng thì lưu tất cả, dừng và chờ họ cho tiếp tục.
- Nguồn lỗi chưa khôi phục được thì bàn giao phần có thật. Đầu transcript
  và tóm tắt tạm đều có “CHƯA ĐẦY ĐỦ” cùng khoảng thiếu cụ thể.

## Tóm tắt sau transcript

Chỉ viết bản tóm tắt cuối sau khi transcript đã lưu và được kiểm tra toàn
phạm vi. tom-tat-lop-hoc.html gồm nguồn, phạm vi/độ đầy đủ, mục lục, liên
kết transcript, chương theo mốc, nội dung chính, quy trình từng bước, ví dụ
quan trọng, điều kiện/lần sửa quyết định kết quả, kết luận và bài tập thật.
Tóm tắt được rút ý/diễn đạt lại nhưng không làm sai hoặc thêm nội dung.

Bài tập/tiêu chí chỉ ghi theo nguồn. Không tự thêm prompt mẫu, lời khuyên,
ứng dụng doanh nghiệp hoặc “bài học rút ra” do agent nghĩ thêm. Kết quả
người nói kể phải ghi theo lời họ, không biến thành chứng cứ agent xác nhận.
Tài liệu áp dụng riêng chỉ tạo khi được yêu cầu và tách khỏi tóm tắt nguồn.

Ảnh thật nếu có, đúng slide/mốc, không ảnh minh họa tự tạo thay bản ghi.
HTML dễ đọc trên điện thoại, mở offline, ID duy nhất, liên kết đúng. Chưa
nhìn được slide thì báo giới hạn đó, không nói đã đối chiếu hình.

## Nghiệm thu

1. Đúng bài, phạm vi và mode. Giữ file gốc và raw; dữ liệu cũ được sao lưu
   trước thay đổi lớn. Không chạm sources/.
2. Đã duyệt toàn phạm vi lời nói, loại trùng replay theo mốc, giữ lời nhắc
   lại thật, không có đoạn bị bỏ chỉ vì tua/tăng tốc. Kiểm tra tên/số liệu
   và bất định. Video hết không chứng minh transcript đủ.
3. SRT tổng đúng mốc nếu có; nếu chưa khớp thì dùng SRT từng đoạn và mapping.
4. Transcript lưu trước, tóm tắt riêng sau; bản tóm tắt dẫn đúng nguồn,
   không thay transcript bằng danh sách ý chính.
5. Khoảng thiếu và trạng thái đủ/thiếu khớp cả transcript, JSON và HTML.
6. Nếu dùng recorder: STOP ở output gốc, xác minh recording_active=false,
   tiến trình đã thoát và cleanup_issues. File-only: không áp kiểm tra
   recorder/định tuyến, nhưng kiểm tra hủy nhận dạng và giữ file gốc.
7. Bàn giao các đường dẫn thật, phân biệt kết quả thử thật với mô phỏng,
   không hứa tiếp tục sau khi lượt chat đã dừng.
