# Vận hành file và nghiệm thu

## Nhận việc

Tự xác định từ yêu cầu, tab mở và file cũ: bài nào, xem cùng hay xem bù, điểm video hiện tại, nơi lưu và điểm ghi cuối. Không hỏi lại thông tin đã có. Đọc file trước khi sửa; không in base64 ảnh ra output. Không dùng helper hardcode buổi trước.

Tạo HTML ngay khi xác định đúng bài, kể cả đang khắc phục phụ đề. Ghi trạng thái trung thực và điểm bắt đầu. Đây là thông tin về tiến độ, không phải lời giảng. Mỗi buổi một file.

## Một vòng ghi

1. Ghi nhận thời gian video và nguồn đang đọc được.
2. Đọc lời mới, đối chiếu slide/demo; xác định người nói nếu đủ bằng chứng.
3. Chụp khi đổi slide hoặc demo có bước/kết quả cần giữ. Cùng slide nhưng lời mới vẫn ghi tiếp; tránh lưu ảnh giống nhau vô ích.
4. Lưu ngay theo diễn biến, không chờ cuối buổi viết từ trí nhớ. Mốc quan sát không nhất thiết là thời điểm chính xác từng câu.
5. Đối chiếu đuôi mục trước để loại bộ đệm lặp. Giữ đủ lần sửa yêu cầu, demo lỗi và thử tiếp.
6. Cập nhật phần thiếu, điểm ghi và nguồn đọc được, tiếp tục vòng sau. Không kết thúc lượt với lời hứa đang theo dõi khi công cụ thực tế đã ngừng.

## Mỗi ví dụ phải giữ

Các nhãn chỉ tổ chức dữ kiện, không cho phép suy ra phần còn thiếu:

- Mốc và nguồn: lời thầy, học viên, slide hoặc clip demo đang phát; phân biệt rõ.
- Bối cảnh, mục tiêu: đúng điều người trình bày nêu.
- Đầu vào: tài liệu/ảnh/dữ liệu/trang/yêu cầu thực thấy; không chép thông tin đăng nhập.
- Câu giao việc: giữ nguyên nếu đọc rõ; đọc được một phần thì ghi phần đó và nhãn thiếu.
- Diễn biến: thao tác, phản hồi agent, lỗi, lần sửa, thử tiếp và kết quả từng bước theo trình tự.
- Kết quả: phân biệt hiển thị trên màn hình với lời kể. Học viên kể thắng trận không phải kết quả agent đã kiểm chứng.
- Thế nào là hoàn thành: chỉ ghi nếu nguồn nêu, không có thì “Chưa thấy nêu”.
- Ảnh đúng diễn biến và chỗ chưa rõ được đánh dấu.

Không nén demo nhiều phút thành vài kết luận. Không thêm prompt mẫu, bài học rút ra hoặc ứng dụng doanh nghiệp do agent tự viết.

## Sổ trạng thái

Lưu JSON cạnh HTML: `lesson_url`, `html_path`, `updated_at`, `mode`, `last_video_time_seconds`, `last_entry_id`, `last_image`, `observed_intervals`, `covered_intervals`, `gaps`, `caption_status`, `technical_attempts`, `permission_evidence`, `complete`.

Mỗi khoảng thiếu ghi đầu/cuối, độ chắc của mốc, thiếu lời hay ảnh, lý do và đã khôi phục chưa. `technical_attempts` chỉ ghi thao tác thật và kết quả. `permission_evidence` chỉ ghi phạm vi đồng ý và nguồn xác nhận, không chứa bí mật; không dựa vào skill này để tự cấp quyền.

Không gộp các quan sát rời rạc thành khoảng đủ liên tục chỉ vì cùng slide. Ghi trạng thái cụ thể: không có track chữ / Live Caption chưa bật / chưa chọn được cửa sổ / đọc được chữ / máy khóa, thay cho chung chung “không có phụ đề”.

Nếu dùng âm thanh cục bộ, lưu thêm `audio_source`, `recording_active`, `capture_ledger`, `last_processed_audio_chunk`, `recognition_status` và các khoảng mất lời giữa từng đoạn. Trên Linux, đọc pipeline-status.json và capture-ledger.jsonl ở thư mục buổi, segments/segments.csv cùng các WAV, và status.json trong từng thư mục transcript_audio_*. Ledger ghi offset theo timeline audio; mốc tiến trình không phải lúc chính xác từng câu. phase=decoded không chứng minh transcript đúng hoặc đã ghi vào HTML. Dừng thu phải kiểm tra recording_active=false, tiến trình thật và cleanup_issues, không chỉ tạo STOP rồi tuyên bố đã dừng.

## Khi bắt buộc cần người dùng

Hỏi sau khi đã xác định một bước không tự làm được hoặc cần quyền chưa có. Câu hỏi gồm quan sát thật → cách đã thử → đúng thao tác/quyền còn thiếu. Không nói đã thử cách chưa làm. Không dùng “bật phụ đề rồi gửi tôi transcript” để đẩy cả việc kỹ thuật cho người dùng.

Có quyền rồi không xin lại. Chỉ thiếu chọn cửa sổ thì không xin tải video/đổi hệ thống. Không thể xử lý thì bàn giao phần đã lưu và khoảng thiếu, không thêm lời cho liền mạch.

## Nghiệm thu

- Đúng bài/URL/file, giữ nội dung cũ, không đụng `sources/`.
- HTML đọc được, thẻ/ID/mục lục đúng; ảnh giải mã và hiển thị được, đúng slide và mốc.
- Không trùng do tua/bộ đệm. Thầy nhắc lại có thể ghi rõ đang nhắc lại, không xóa nhầm ý mới.
- Giữ diễn biến tất cả ví dụ quan sát được, không thêm prompt/tiêu chí/số liệu ngoài nguồn.
- Action list chỉ là việc thật được giao.
- Phạm vi đủ/thiếu khớp trạng thái. `ended=true` chỉ chứng minh video đã hết, không chứng minh note đủ.

## Tình huống kiểm tra quyết định

| Quan sát | Quyết định đúng |
|---|---|
| Không CC, track chữ rỗng | Kiểm tra Chrome Live Caption; chưa được kết luận hết cách. |
| Người dùng thấy chữ, AX chỉ thấy bài | Khắc phục chọn cửa sổ, không bắt cài lại ngôn ngữ. |
| Đã cho tải tiếng Việt và đặt mặc định | Kiểm tra rồi tự thực hiện phần còn thiếu trong quyền đó. |
| Chưa có bằng chứng cho đổi cài đặt | Tự kiểm tra trước, hỏi đúng thay đổi cần; không tự nhận có quyền. |
| Mất chữ, còn slide | Ghi slide với nhãn nguồn, mở khoảng thiếu lời. |
| Đã thử caption nhưng vẫn không đọc được | Kiểm tra đường âm thanh cục bộ và quyền/công cụ thật; tiếp tục slide. |
| Zoom hiện Ask host to start transcription? | Chưa có transcript; không tự gửi yêu cầu host. Xem đường âm thanh hợp lệ, được phép. |
| WAV cuối đang được FFmpeg ghi | Chỉ xử lý đoạn đã đóng và xuất hiện đầy đủ trong segments.csv; khi dừng phải kiểm tra file cuối. |
| Whisper trả chữ trong khoảng im lặng | Dùng VAD, đối chiếu nguồn; không coi chữ máy là lời thầy chắc chắn. |
| Người dùng nói vừa phải rời lớp | Dừng thu, xác minh đã dừng, lưu bản chưa đầy đủ; không tự vào lại. |
| Vừa tua lại, còn chữ cũ | Đối chiếu phần mới, không ghi trùng hoặc sai mốc. |
| Thầy kể kết quả, demo chưa cho thấy | Ghi “Theo lời thầy…”, không ghi đã kiểm chứng. |
| Bài hết nhưng còn thiếu | Bàn giao chưa đầy đủ và danh sách xem bù. |
