# Nghe cục bộ cho Hermes trên Linux

## Chế độ bản ghi và transcript

Mặc định Hermes tự xử lý bản ghi: lưu toàn bộ transcript trước, tóm tắt
lớp học riêng sau. Được phát/dừng, tua, đổi tốc độ và mở lại bài trong
phạm vi truy cập đã có. Nếu có file hợp lệ, ưu tiên mục File mode, không
phát rồi thu lại. Live capture trong tài liệu là thu tiếng player đang
phát, không đồng nghĩa lớp live cùng người dùng.

## Điều kiện thật

Python 3.9+, FFmpeg có input `pulse`, ffprobe, whisper-cli có `--vad`/`-vm`,
model Whisper và Silero VAD có sẵn. Live cần Linux, `pactl` hỗ trợ JSON và
PulseAudio hoặc PipeWire có `pipewire-pulse`. File mode không cần pactl hay
Linux. CPU mặc định. Helper không dùng công cụ UI của Codex, không có mạng,
không tự cài phần mềm, tải model hoặc cấp quyền.

Hermes phải truy cập được audio server của phiên đang phát bài. Chạy
trong container/service/SSH có thể thiếu socket/quyền; không sửa quyền
socket, mở server ra mạng, dùng sudo hay chép cookie để lách. Xác minh môi
trường được cấu hình hợp lệ; báo đúng giới hạn nếu không có nguồn.

## 1. Kiểm tra chỉ đọc

Từ thư mục skill (thay đường dẫn thật; không giả định thư mục Codex):

```bash
python3 scripts/listen_linux.py --check
python3 scripts/listen_linux.py --help
python3 scripts/transcribe_file.py --help
```

`--check` không cần model, không tạo file, không định tuyến/thu. Nó liệt kê
sink-input ID, app/PID, sink, sources và sự có mặt của công cụ. Không phải
kiểm tra toàn bộ dependency: phải kiểm tra FFmpeg có input pulse, Whisper
và model chạy được ở bước thử. Bản pactl không có JSON thì báo chưa hỗ trợ.

Đối chiếu bài đang mở qua công cụ thực tế. Chọn chính xác các luồng phát
thuộc bài; không chọn tất cả luồng của Chrome theo tên. Một browser stream
có thể trộn nhiều tab: không hứa tách tab chỉ bằng PID hoặc cửa sổ riêng.
Không thu monitor của loa chung, default source hay micro làm đường dự phòng.

## 2. Định tuyến và thử 30 giây

Trong phạm vi nhiệm vụ/quyền đã có, thay các placeholder dưới đây bằng dữ
liệu mới xác minh. Không chạy nguyên xi. Mỗi `--out` phải mới.

```bash
python3 scripts/listen_linux.py --start \
  --sink-input VERIFIED_STREAM_ID \
  --hear-sink VERIFIED_ORIGINAL_OUTPUT_NAME \
  --model /absolute/path/existing-whisper-model.bin \
  --vad-model /absolute/path/existing-silero-model.bin \
  --minutes 0.5 --chunk-seconds 30 \
  --out /absolute/workspace/lesson/trial-new
```

Có thể lặp `--sink-input` cho nhiều luồng đã xác minh đều thuộc bài. Bỏ
`--hear-sink` nếu không cần nghe cùng: khi tiếng ứng dụng đi vào sink ảo,
người dùng sẽ không còn nghe luồng đó qua loa cũ nếu không có loopback.
Trong chế độ tự xem bản ghi, không bắt buộc loopback. Nếu cần nghe cùng,
dùng loopback đến output thật đã kiểm tra, không
về chính sink ảo/monitor và không vào mic.

Helper tạo sink tên ngẫu nhiên, chuyển các ID đã chọn và kiểm tra nhận
dạng client/app/PID của chúng. Nó không đổi default sink. Monitor của sink
riêng là đầu vào FFmpeg; không đăng ký micro hoặc video. Lưu trạng thái
routing và ledger ngay khi thay đổi. Nếu source không rõ, input đổi/mất,
hay có luồng khác trong sink riêng thì dừng. Việc kiểm tra mỗi khoảng 0,5
giây và buffering có thể có độ trễ: không hứa cách ly tuyệt đối.

Đọc `pipeline-status.json`, `capture.log`, `segments/segments.csv`, các WAV,
`transcript_audio_*/status.json`, `audio-metadata.json`, `speech.txt`,
`speech.srt`. Chỉ nhận dạng file CSV báo đã đóng; file đang ghi không dùng.
Xem thời lượng đo và RMS. File gần như im lặng không gọi Whisper. VAD giảm
chữ bịa nhưng không chứng minh chữ đúng; kiểm tra đoạn có lời và đối chiếu
slide. Không gọi build/check hay file rỗng là đã nghe được.

## 3. Thu tiếp và chép toàn bộ lời

Sau thử đạt, dùng output mới, thời hạn rõ (tối đa 240 phút một lần), thường
30 giây mỗi đoạn. Không hứa tiếp tục qua giới hạn hoặc cuối lượt chat.
FFmpeg thu liên tục bằng segment muxer, CSV báo offset tương đối từng đoạn.
Đây không phải timecode video và không bảo đảm không mất mẫu. Ghi offset,
mốc quan sát và khoảng chuyển/thiếu thật; không khôi phục phần trước lúc thu.

Trước khi tua/đổi tốc độ/mở lại: dừng lượt thu, kiểm tra file đóng, lưu
mốc player và tốc độ. Sau thao tác xác minh lại vị trí/tốc độ/nguồn, tạo
output mới và playback_session mới. Bắt đầu thử ở 1×; chỉ tăng tốc khi đã
so chất lượng tiếng Việt. CSV/SRT là timeline audio thu, không phải video
gốc khi player tăng tốc. Ghi bảng ánh xạ; nếu không đủ bằng chứng thì
giữ mốc ước lượng, không tạo SRT tổng có mốc giả.

Chỉ một tiến trình nhận dạng chạy mỗi lúc. Khi số đoạn đang chờ/chạy đạt
ba, dừng recorder, đóng đoạn cuối (đoạn cuối có thể tăng thêm một file cần
xử lý), ghi `transcription_backlog`, xử lý audio đã thu rồi kết thúc. Từ
lúc dừng phải mở khoảng thiếu, giữ audio. Với recorded_review, Hermes
được dừng player, xử lý tồn đọng rồi tua về điểm chưa xử lý để tiếp tục
bằng output mới sau khi kiểm tra nguồn. Không tiếp tục nếu đó là STOP
của người dùng; không xóa STOP để tái dùng output.
Lỗi nhận dạng cũng dừng recorder. Không có tiến triển byte trong 15 giây
thì dừng báo lỗi; im lặng có mẫu PCM vẫn là audio hợp lệ.

Whisper CPU có thể chậm hơn thời gian thực. `--gpu` chỉ dùng sau khi đã
kiểm tra có backend phù hợp; không lặp vô cớ lệnh GPU thất bại. Giảm model
chỉ khi model có sẵn được phép và thử chất lượng tiếng Việt đạt yêu cầu.

Hermes giữ raw TXT/SRT, ghép toàn bộ lời theo thứ tự bản ghi vào
transcript-toan-bai.txt, so slide/demo, cập nhật sổ buổi. Chỉ sau khi đã
lưu/kiểm tra transcript mới viết tom-tat-lop-hoc.html. Helper không tự ghép
toàn bài hay tóm tắt. Không nhìn được slide thì giữ nhãn thiếu hình.

## 4. File mode — ưu tiên khi có file hợp lệ

```bash
python3 scripts/transcribe_file.py \
  --input /absolute/path/authorized-audio-or-video \
  --model /absolute/path/existing-whisper-model.bin \
  --vad-model /absolute/path/existing-silero-model.bin \
  --out /absolute/workspace/lesson/file-new
```

File gốc chỉ đọc. Không tái dùng output. Tạo WAV PCM16 mono 16 kHz, đo
thời lượng/RMS, Whisper tiếng Việt + VAD, TXT/SRT. CPU mặc định, `--check`
chỉ xác minh đường dẫn/tool, không tải model hay chứng minh nhận dạng đạt.
SRT tương đối trong file, không suy đoán người nói hoặc timecode video.
Nếu file quá dài cho bộ nhớ/timeout, chia bản sao thành đoạn có offset gốc
biết được và nhận dạng từng đoạn vào output mới. Không bỏ phần cuối; ghép
đủ lời theo offset, giữ nguyên raw và file gốc. Đây là việc Hermes phải
điều phối; helper file không tự chia hoặc tự ghép toàn bài.

## 5. Dừng và khôi phục

Khi người dùng yêu cầu pause/dừng, cần đổi playback hoặc mất nguồn, tạo file `STOP`
trong output gốc của `listen_linux.py` (hoặc gửi SIGTERM đến đúng PID cha
được phiên này tạo). Kiểm tra `phase=stopped`, `recording_active=false`,
tiến trình đã thoát, `cleanup_issues` và ledger. STOP trong output của
`transcribe_file.py` chỉ dừng nhận dạng file đó, không dừng recorder cha.

Helper TERM tiến trình con do nó tạo, chờ đóng file, chỉ KILL con đó nếu
không thoát đúng hạn; không dùng killall/pkill. Nhận dạng đang chạy/chờ có
thể bị hủy, audio giữ nguyên để xử lý file sau khi được giao. CSV/file cuối
cần kiểm tra, đặc biệt khi recorder bị kill hoặc máy mất điện.

Khôi phục luồng còn ở sink riêng về sink ban đầu nếu nhận dạng luồng và
sink ban đầu còn hợp lệ. Không kéo luồng đã được người dùng chuyển đi về
chỗ cũ. Gỡ chỉ module tự tạo, kiểm tra ID/tên/argument trước. Nếu còn luồng
trong sink riêng hoặc cleanup lỗi, giữ tài nguyên và báo lỗi thay vì ép
gỡ làm ảnh hưởng nguồn khác. Không tuyên bố đã khôi phục hết khi còn issue.

SIGKILL/mất điện không chạy cleanup: dùng `routing.json` và ledger để
Hermes kiểm tra lại ID/ownership rồi sửa trong phạm vi được phép; không
chạy lệnh gỡ mù theo ID cũ. Được mở lại bản ghi sau gián đoạn trong nhiệm
vụ recorded_review, kiểm tra vị trí, tốc độ và nguồn, dùng output mới.
Không tự Join cuộc họp live hay xóa STOP của người dùng để thu tiếp.

## 6. Kiểm chứng và giới hạn

Gói được kiểm tra logic định tuyến/dừng bằng audio server giả và FFmpeg
thật với âm thanh tổng hợp; file silence được kiểm tra không gọi Whisper.
Không coi đó là thử trực tiếp Linux hoặc thử chất lượng tiếng Việt/model
trên máy Hermes. Trước dùng thật phải thu thử với đúng app/server/quyền và
kiểm tra nguồn, âm lượng nghe cùng, latency, nhận dạng và khôi phục.

Không tự tạo buổi ghi thật để nghiệm thu việc cài skill. Không đánh dấu
live-ready chỉ vì nhận diện được tên skill hoặc chạy --help thành công.

## Căn cứ

- [PulseAudio modules / null sink / loopback](https://wiki.freedesktop.org/www/Software/PulseAudio/Documentation/User/Modules/)
- [PipeWire PulseAudio compatibility server](https://pipewire.pages.freedesktop.org/pipewire/page_man_pipewire-pulse_1.html)
- [FFmpeg pulse input](https://ffmpeg.org/ffmpeg-devices.html#pulse)
- [FFmpeg segment muxer](https://ffmpeg.org/ffmpeg-formats.html#segment)
