#!/usr/bin/env python3
"""Isolate explicitly selected PulseAudio playback streams and capture locally.

Requires Linux + PulseAudio or PipeWire's PulseAudio compatibility server.
Default is read-only inspection. --start authorizes temporary audio routing;
the agent must first obtain the user's task/permission and verify stream identity.
No installation, network calls, microphone input, screen capture or global kills.
"""
import argparse
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import uuid

from transcribe_file import stop_process


def stamp():
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


class Pulse:
    def __init__(self, command='pactl'):
        self.command = command

    def call(self, *args):
        return subprocess.run([self.command, *map(str, args)], check=True,
                              capture_output=True, text=True, timeout=10).stdout.strip()

    def listing(self, kind):
        result = json.loads(self.call('-f', 'json', 'list', kind))
        if not isinstance(result, list):
            raise ValueError('pactl JSON list unsupported')
        return result


def identity(stream):
    props = stream.get('properties', {})
    return (str(stream.get('client')), props.get('application.process.id'),
            props.get('application.process.binary'), props.get('application.name'))


class Route:
    """Track only resources created here; never reset defaults or other streams."""
    def __init__(self, pulse, ids, event):
        self.pulse, self.ids, self.event = pulse, set(ids), event
        self.name = 'lesson_' + uuid.uuid4().hex[:16]
        self.original = {}
        self.modules = []
        self.sink_id = None
        self.cleanup_issues = []

    def setup(self, hear_sink=None):
        sinks = {str(s['index']): s for s in self.pulse.listing('sinks')}
        streams = {int(s['index']): s for s in self.pulse.listing('sink-inputs')}
        if not self.ids or not self.ids.issubset(streams):
            raise ValueError('Selected stream disappeared; inspect again')
        for index in self.ids:
            stream = streams[index]
            sink = sinks.get(str(stream.get('sink')))
            if sink is None:
                raise ValueError('Original sink cannot be identified')
            self.original[index] = dict(identity=identity(stream), sink=sink['name'])
        if hear_sink and hear_sink not in {s['name'] for s in sinks.values()}:
            raise ValueError('--hear-sink must name an existing verified output')
        if hear_sink and hear_sink.endswith('.monitor'):
            raise ValueError('--hear-sink must be an output, not a monitor')
        module = int(self.pulse.call('load-module', 'module-null-sink',
                                     'sink_name=' + self.name,
                                     'sink_properties=device.description=LessonLocal'))
        self.modules.append((module, 'module-null-sink'))
        self.event('module_created', module=module, name='module-null-sink')
        matches = [s for s in self.pulse.listing('sinks') if s.get('name') == self.name]
        if len(matches) != 1:
            raise RuntimeError('Private sink not found after creation')
        self.sink_id = str(matches[0]['index'])
        if str(matches[0].get('owner_module')) != str(module):
            raise RuntimeError('Private sink ownership mismatch')
        for index in sorted(self.ids):
            # Re-read identity before each mutation to reject stale numeric IDs.
            current = {int(s['index']): s for s in self.pulse.listing('sink-inputs')}
            if index not in current or identity(current[index]) != self.original[index]['identity']:
                raise RuntimeError('Selected stream changed before routing')
            self.pulse.call('move-sink-input', index, self.name)
            self.event('stream_moved', stream=index, original_sink=self.original[index]['sink'])
        if hear_sink:
            module = int(self.pulse.call('load-module', 'module-loopback',
                                         'source=' + self.name + '.monitor',
                                         'sink=' + hear_sink))
            self.modules.append((module, 'module-loopback'))
            self.event('module_created', module=module, name='module-loopback')
        self.verify()

    def verify(self):
        streams = self.pulse.listing('sink-inputs')
        routed = {int(s['index']): s for s in streams if str(s.get('sink')) == self.sink_id}
        if set(routed) != self.ids:
            raise RuntimeError('Selected stream missing or unrelated stream entered private sink')
        for index, stream in routed.items():
            if identity(stream) != self.original[index]['identity']:
                raise RuntimeError('Playback identity changed; re-inspection required')

    def cleanup(self):
        # Retain the null sink if moving a stream back would affect a new owner
        # or if restoration fails. Record unresolved resources for manual recovery.
        try:
            sinks = {s['name'] for s in self.pulse.listing('sinks')}
            streams = {int(s['index']): s for s in self.pulse.listing('sink-inputs')}
            for index, original in self.original.items():
                stream = streams.get(index)
                if stream is None or str(stream.get('sink')) != self.sink_id:
                    continue
                if identity(stream) != original['identity']:
                    self.cleanup_issues.append('Identity changed for stream ' + str(index))
                    continue
                if original['sink'] not in sinks:
                    self.cleanup_issues.append('Original sink missing for stream ' + str(index))
                    continue
                try:
                    self.pulse.call('move-sink-input', index, original['sink'])
                    self.event('stream_restored', stream=index)
                except Exception as error:
                    self.cleanup_issues.append('Restore failed: ' + str(error))
            modules = {int(m['index']): m for m in self.pulse.listing('modules')}
            for module, name in reversed(self.modules):
                current = modules.get(module)
                if current is None:
                    continue
                if current.get('name') != name or self.name not in str(current.get('argument', '')):
                    self.cleanup_issues.append('Module identity changed: ' + str(module))
                    continue
                if name == 'module-null-sink':
                    remaining = [s for s in self.pulse.listing('sink-inputs')
                                 if str(s.get('sink')) == self.sink_id]
                    if remaining:
                        self.cleanup_issues.append('Private sink retained: streams remain attached')
                        continue
                try:
                    self.pulse.call('unload-module', module)
                    self.event('module_removed', module=module)
                except Exception as error:
                    self.cleanup_issues.append('Module removal failed: ' + str(error))
        except Exception as error:
            self.cleanup_issues.append('Cleanup inspection failed: ' + str(error))
        return self.cleanup_issues


def closed_segments(path, root):
    """FFmpeg CSV rows are written on segment close; ignore incomplete rows."""
    if not path.exists():
        return []
    rows = []
    lines = path.read_text(encoding='utf-8').splitlines(keepends=True)
    for line in lines:
        if not line.endswith('\n'):
            continue
        try:
            row = next(csv.reader([line]))
            if len(row) != 3:
                continue
            audio = (root / row[0]).resolve()
            begin, end = float(row[1]), float(row[2])
            if audio.parent != root.resolve() or not audio.name.startswith('audio_'):
                raise ValueError('Segment outside capture directory')
            if end > begin and audio.is_file():
                rows.append((audio, begin, end))
        except (csv.Error, StopIteration):
            continue
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', action='store_true', help='Start temporary routing and recording')
    parser.add_argument('--check', action='store_true', help='Read-only preflight, no routing or capture')
    parser.add_argument('--sink-input', type=int, action='append', default=[],
                        help='Verified playback stream ID; repeat for multiple lesson streams')
    parser.add_argument('--hear-sink', help='Verified existing output name for optional listening loopback')
    parser.add_argument('--out', type=Path, help='New session directory; must not exist')
    parser.add_argument('--model', type=Path)
    parser.add_argument('--vad-model', type=Path)
    parser.add_argument('--minutes', type=float, default=.5, help='Bounded session, default 30-second trial')
    parser.add_argument('--chunk-seconds', type=float, default=30)
    parser.add_argument('--gpu', action='store_true', help='CPU is default')
    args = parser.parse_args()
    if args.start and args.check:
        parser.error('--start and --check are mutually exclusive')
    if not sys.platform.startswith('linux'):
        parser.error('Live capture is Linux-only; file transcription is portable')
    if not 0 < args.minutes <= 240 or not 1 <= args.chunk_seconds <= 300:
        parser.error('Require 0 < minutes <= 240 and 1 <= chunk-seconds <= 300')
    if not shutil.which('pactl'):
        parser.error('pactl is missing; nothing installed automatically')
    pulse = Pulse()
    try:
        inputs = pulse.listing('sink-inputs')
        sinks = pulse.listing('sinks')
        sources = pulse.listing('sources')
        info = {'checked_at': stamp(), 'recording_active': False,
                'streams': [{'id': s['index'], 'sink': s.get('sink'),
                             'application': s.get('properties', {}).get('application.name'),
                             'process': s.get('properties', {}).get('application.process.binary'),
                             'pid': s.get('properties', {}).get('application.process.id')}
                            for s in inputs],
                'sinks': [{'id': s['index'], 'name': s['name']} for s in sinks],
                'sources': [{'name': s['name']} for s in sources],
                'tools': {key: bool(shutil.which(key)) for key in ('ffmpeg', 'ffprobe', 'whisper-cli')}}
        if not args.start:
            print(json.dumps(info, ensure_ascii=False, indent=2))
            return 0
        if not args.sink_input or args.out is None or args.model is None or args.vad_model is None:
            parser.error('--start needs --sink-input, --out, --model and --vad-model')
        for tool in ('ffmpeg', 'ffprobe', 'whisper-cli'):
            if not shutil.which(tool):
                parser.error('Missing installed tool: ' + tool)
        devices = subprocess.run(['ffmpeg', '-hide_banner', '-devices'], check=True,
                                 capture_output=True, text=True, timeout=10)
        if not any('pulse' in line and 'D' in line.split()[0]
                   for line in (devices.stdout + devices.stderr).splitlines() if line.split()):
            parser.error('Installed FFmpeg has no PulseAudio input')
        for key in ('model', 'vad_model'):
            value = getattr(args, key).expanduser().resolve()
            if not value.is_file():
                parser.error('Missing model file; nothing downloaded automatically')
            setattr(args, key, value)
    except (subprocess.SubprocessError, ValueError, OSError) as error:
        parser.error('Audio session preflight failed: ' + str(error))
    root = args.out.expanduser().resolve()
    if root.exists():
        parser.error('Output exists; choose a new directory')
    root.mkdir(parents=True)
    segments = root / 'segments'
    segments.mkdir()
    stop = root / 'STOP'
    status = {'phase': 'preparing', 'recording_active': False, 'started_at': stamp()}
    def event(kind, **data):
        with (root / 'capture-ledger.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(dict(time=stamp(), kind=kind, **data), ensure_ascii=False) + '\n')
    def save(**data):
        status.update(data, updated_at=stamp())
        atomic_json(root / 'pipeline-status.json', status)
    def request_stop(*unused):
        stop.touch()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, request_stop)
    route = Route(pulse, args.sink_input, event)
    recorder = decoder = None
    record_log = decode_log = None
    active = None
    queue = []
    seen = set()
    reason = 'duration_limit'
    failed = False
    cleanup_issues = []
    save()
    try:
        atomic_json(root / 'preflight.json', info)
        if stop.exists():
            raise InterruptedError('Stop requested before routing')
        route.setup(args.hear_sink)
        atomic_json(root / 'routing.json', {'private_sink': route.name,
                    'original_streams': route.original, 'created_modules': route.modules})
        if stop.exists():
            raise InterruptedError('Stop requested during routing')
        record_log = (root / 'capture.log').open('wb')
        command = ['ffmpeg', '-nostdin', '-n', '-hide_banner', '-loglevel', 'warning',
                   '-f', 'pulse', '-i', route.name + '.monitor', '-t', str(args.minutes * 60),
                   '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le',
                   '-f', 'segment', '-segment_time', str(args.chunk_seconds),
                   '-reset_timestamps', '1', '-segment_list', 'segments.csv',
                   '-segment_list_type', 'csv', '-segment_list_size', '0', 'audio_%06d.wav']
        recorder = subprocess.Popen(command, cwd=segments, stdout=record_log, stderr=record_log)
        recording_started = stamp()
        save(phase='capturing', recording_active=True, recorder_pid=recorder.pid,
             capture_started_at=recording_started, source=route.name + '.monitor')
        event('capture_started', pid=recorder.pid, source=route.name + '.monitor',
              note='wall time is process launch, not exact first audio sample')
        deadline = time.monotonic() + args.minutes * 60 + 15
        last_audio_progress = time.monotonic()
        last_bytes = 0
        next_route_check = 0
        while True:
            if stop.exists():
                raise InterruptedError('STOP requested')
            if decoder is not None and decoder.poll() is not None:
                code = decoder.returncode
                decode_log.close()
                decode_log = None
                event('decode_finished', chunk=active, exit_code=code)
                if code:
                    raise RuntimeError('Recognition failed; input audio preserved')
                decoder = None
                active = None
            for audio, begin, end in closed_segments(segments / 'segments.csv', segments):
                if audio.name not in seen:
                    seen.add(audio.name)
                    queue.append((audio, begin, end))
                    event('segment_closed', file=audio.name, offset_seconds=begin,
                          end_seconds=end, origin='FFmpeg media timeline; not video timecode')
            if len(queue) + int(decoder is not None) >= 3 and recorder.poll() is None:
                reason = 'transcription_backlog'
                stop_process(recorder)
                event('capture_stopped', reason=reason)
                save(phase='finishing_transcripts', recording_active=False, reason=reason)
                # Re-read final CSV on next iteration to preserve the last closed segment.
                continue
            if time.monotonic() >= next_route_check and recorder.poll() is None:
                route.verify()
                next_route_check = time.monotonic() + .5
            if decoder is None and queue:
                audio, begin, end = queue.pop(0)
                output = root / ('transcript_' + audio.stem)
                active = audio.name
                command = [sys.executable, str(Path(__file__).with_name('transcribe_file.py')),
                           '--input', str(audio), '--out', str(output), '--model', str(args.model),
                           '--vad-model', str(args.vad_model)]
                if args.gpu:
                    command.append('--gpu')
                decode_log = (root / ('decode_' + audio.stem + '.log')).open('wb')
                decoder = subprocess.Popen(command, stdout=decode_log, stderr=decode_log)
                event('decode_started', chunk=active, output=output.name, offset_seconds=begin)
            alive = recorder.poll() is None
            save(phase='capturing' if alive else 'finishing_transcripts', recording_active=alive,
                 pending_chunks=len(queue) + int(decoder is not None), processed_or_queued=len(seen))
            if not alive:
                if recorder.returncode and reason != 'transcription_backlog':
                    raise RuntimeError('Recorder failed; inspect capture.log')
                if not queue and decoder is None:
                    # Process may exit between the CSV read and poll(). Re-read
                    # once after exit before declaring every segment processed.
                    final = closed_segments(segments / 'segments.csv', segments)
                    if all(audio.name in seen for audio, begin, end in final):
                        break
            else:
                byte_count = sum(p.stat().st_size for p in segments.glob('audio_*.wav'))
                if byte_count != last_bytes:
                    last_bytes = byte_count
                    last_audio_progress = time.monotonic()
                if time.monotonic() - last_audio_progress > 15:
                    raise RuntimeError('No audio data progress for 15 seconds')
                if time.monotonic() > deadline:
                    raise TimeoutError('Capture exceeded bounded duration')
            time.sleep(.2)
        if not seen:
            raise RuntimeError('No closed audio segments')
    except InterruptedError:
        reason = 'stop_requested'
    except Exception as error:
        reason, failed = 'error', True
        event('pipeline_error', error=str(error), audio_preserved=True)
    finally:
        try:
            stop_process(recorder)
        except Exception as error:
            failed = True
            event('recorder_stop_failed', error=str(error))
        if decoder is not None and decoder.poll() is None:
            try:
                stop_process(decoder)
            except Exception as error:
                failed = True
                event('decoder_stop_failed', error=str(error))
        if record_log:
            record_log.close()
        if decode_log:
            decode_log.close()
        cleanup_issues = route.cleanup()
        still_recording = recorder is not None and recorder.poll() is None
        failed = failed or still_recording or bool(cleanup_issues)
        # Enumerate original recordings, including interrupted/unprocessed final files.
        event('session_stopped', reason=reason, files=[p.name for p in segments.glob('audio_*.wav')],
              active_decode_at_stop=active, queued_unprocessed=[item[0].name for item in queue],
              cleanup_issues=cleanup_issues)
        save(phase='error' if still_recording else 'stopped', recording_active=still_recording,
             reason=reason, failed=failed, cleanup_issues=cleanup_issues,
             unprocessed_audio_may_remain=reason != 'duration_limit', ended_at=stamp())
    print(root / 'pipeline-status.json')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
