#!/usr/bin/env python3
"""Transcribe a supplied local file using installed tools. No network or capture."""
import argparse
import array
import json
import math
from pathlib import Path
import shutil
import signal
import subprocess
import time
import wave


def stop_process(process):
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


def run(command, log, stop, timeout):
    with log.open('wb') as stream:
        process = subprocess.Popen(command, stdout=stream, stderr=stream)
        deadline = time.monotonic() + timeout
        try:
            while process.poll() is None:
                if stop.exists():
                    raise InterruptedError('STOP requested; input preserved')
                if time.monotonic() > deadline:
                    raise TimeoutError('Tool timed out; inspect local log')
                time.sleep(.1)
            if process.returncode:
                raise RuntimeError('Tool failed; inspect ' + log.name)
        finally:
            stop_process(process)


def audio_metadata(path):
    with wave.open(str(path), 'rb') as audio:
        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate()) != (1, 2, 16000):
            raise ValueError('Expected 16 kHz mono PCM16 WAV')
        count, squares = 0, 0
        while True:
            raw = audio.readframes(16000)
            if not raw:
                break
            samples = array.array('h', raw)
            import sys
            if sys.byteorder != 'little':
                samples.byteswap()
            count += len(samples)
            squares += sum(int(x) ** 2 for x in samples)
    if not count:
        raise ValueError('No audio samples')
    return {'duration_seconds': count / 16000,
            'rms': math.sqrt(squares / count) / 32768,
            'time_origin': 'seconds within this file; not original video timecode'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--vad-model', type=Path, required=True)
    parser.add_argument('--ffmpeg', default='ffmpeg')
    parser.add_argument('--whisper', default='whisper-cli')
    parser.add_argument('--language', default='vi')
    parser.add_argument('--gpu', action='store_true', help='CPU is the default')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    for key in ('input', 'model', 'vad_model'):
        value = getattr(args, key).expanduser().resolve()
        if not value.is_file():
            parser.error('Missing file: ' + str(value))
        setattr(args, key, value)
    for key in ('ffmpeg', 'whisper'):
        value = shutil.which(getattr(args, key))
        if value is None:
            parser.error('Missing tool: ' + getattr(args, key))
        setattr(args, key, value)
    root = args.out.expanduser().resolve()
    if root.exists():
        parser.error('Output exists; choose a new directory')
    if args.check:
        print('Paths checked; no audio processed, models not loaded or downloaded.')
        return 0
    root.mkdir(parents=True)
    stop = root / 'STOP'
    def request_stop(*unused):
        stop.touch()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, request_stop)
    status = {'phase': 'processing', 'recording_active': False}
    def save():
        temp = root / 'status.tmp'
        temp.write_text(json.dumps(status, indent=2), encoding='utf-8')
        temp.replace(root / 'status.json')
    save()
    try:
        wav = root / 'audio.wav'
        run([args.ffmpeg, '-nostdin', '-n', '-hide_banner', '-loglevel', 'error',
             '-i', str(args.input), '-vn', '-ar', '16000', '-ac', '1',
             '-c:a', 'pcm_s16le', str(wav)], root / 'ffmpeg.log', stop, 300)
        metadata = audio_metadata(wav)
        (root / 'audio-metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
        if metadata['rms'] <= .00001:
            # Do not ask Whisper to invent words for an effectively silent file.
            (root / 'speech.txt').write_text('', encoding='utf-8')
            (root / 'speech.srt').write_text('', encoding='utf-8')
            status.update(phase='silent', recognition='not_run_silence')
        else:
            command = [args.whisper, '-m', str(args.model), '-f', str(wav),
                       '-l', args.language, '--vad', '-vm', str(args.vad_model),
                       '-otxt', '-osrt', '-of', str(root / 'speech')]
            if not args.gpu:
                command.insert(1, '-ng')
            run(command, root / 'whisper.log', stop,
                max(300, metadata['duration_seconds'] * 10))
            if not all((root / ('speech.' + ext)).is_file() for ext in ('txt', 'srt')):
                raise RuntimeError('Whisper did not create TXT and SRT')
            status.update(phase='decoded', recognition='machine_text_needs_crosscheck')
    except InterruptedError:
        status.update(phase='stopped', reason='stop_requested', source_preserved=True)
        return 2
    except Exception as error:
        status.update(phase='error', error=str(error), source_preserved=True)
        return 1
    finally:
        save()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
