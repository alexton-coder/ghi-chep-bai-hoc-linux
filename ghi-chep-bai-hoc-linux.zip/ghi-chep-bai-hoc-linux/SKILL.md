---
name: ghi-chep-bai-hoc-linux
description: Ghi chép bài học tiếng Việt cho Hermes trên Linux từ âm thanh cục bộ, phụ đề và slide/demo. Dùng khi được giao nghe cùng lớp, ghi bản ghi hoặc xem bù; hỗ trợ thu đúng luồng ứng dụng qua PulseAudio hoặc PipeWire tương thích PulseAudio, Whisper.cpp và Silero VAD.
---

# Ghi chép bài học trên Linux

Skill độc lập dành cho Hermes. Không phụ thuộc skill Codex hay helper macOS.
Tên riêng `ghi-chep-bai-hoc-linux`: không ghi đè `ghi-chep-bai-hoc` nếu máy đã có.

## Kết quả

Lưu HTML tiếng Việt trong workspace của người dùng, có mục lục, nguồn, mốc,
ảnh slide/demo thực sự thấy, diễn biến ví dụ và danh sách phần thiếu. Lưu sổ
trạng thái JSON cạnh HTML. Đây là ghi chú học tập cá nhân theo phần quan sát
được, không tự biến thành yêu cầu lấy transcript nguyên văn toàn khóa.

Skill hướng dẫn agent và cung cấp script; script không tự đọc màn hình hoặc
viết HTML. TXT/SRT là nguồn trung gian, Hermes phải đọc, đối chiếu rồi ghi.
Không nói đã nghe nếu chỉ đọc slide; không nói đã ghi nếu mới có transcript.

## Nhận việc

1. Đọc yêu cầu hiện tại, file cũ và sổ trạng thái. Chọn đúng buổi, URL,
   ứng dụng, vị trí đang xem, nơi lưu. Tạo file HTML ngay cả khi đang xử lý
   âm thanh; không trộn các buổi, không sửa `sources/`.
2. Xác định xem cùng hay xem bù. Xem cùng thì giữ nhịp phát của người dùng,
   không tự tua, dừng hoặc đổi tốc độ. Xem bù mới quay lại khoảng thiếu.
3. Kiểm tra công cụ Hermes thực sự có. Không gọi công cụ Codex/CUA tưởng
   tượng. Dùng giao diện được hỗ trợ để xem slide/demo, không đọc URL media
   ẩn, không vượt chặn tải/thu và không tự vào lớp bằng tài khoản khác.
4. Nếu người dùng đã chọn nghe cục bộ, đi thẳng kiểm tra âm thanh Linux.
   Nếu caption đang dùng được, có thể đọc nó và đối chiếu slide. Caption
   thất bại thì mở khoảng thiếu lời, tiếp tục slide và chuyển nhánh nghe;
   không lặp thao tác caption thất bại mãi hoặc đẩy việc kỹ thuật cho người dùng.

## Nhánh nghe Linux

Đọc [references/linux-audio.md](references/linux-audio.md) trước khi thu,
định tuyến hoặc xử lý sự cố. Bộ thu hỗ trợ PulseAudio và PipeWire có
`pipewire-pulse`/pactl JSON. PipeWire thuần chưa có backend đi kèm: báo giới
hạn, không tự chuyển sang micro hoặc thu toàn hệ thống.

- Phiên Linux của Hermes phải kết nối được audio server của ứng dụng đang
  phát bài. Cùng máy nhưng chạy trong service/container/SSH chưa chứng minh
  có quyền. Hermes trên máy chủ khác không tự nghe được Zoom đang ở Mac.
- Kiểm tra chỉ đọc trước. Tự tìm đúng sink-input bằng tên ứng dụng, PID và
  ngữ cảnh bài học. Không tái sử dụng ID từ buổi cũ; PID/tên chưa đủ để hứa
  cô lập một tab trình duyệt. Chỉ chọn các luồng đã xác minh thuộc bài học.
- Script tạo sink riêng, chuyển đúng các luồng đã chọn, thu monitor riêng.
  Không thu microphone, hình hoặc monitor loa chung. Nếu nguồn biến mất,
  đổi nhận dạng hoặc luồng khác đi vào sink riêng, dừng và đánh dấu thiếu.
  Có độ trễ kiểm tra nguồn; không hứa tuyệt đối không lẫn tiếng hoặc không
  mất mẫu. Không chọn luồng không liên quan để thử sự cô lập.
- Đọc quyền đã có. Khi đã được giao nghe cục bộ và định tuyến nằm trong
  phạm vi đó, tiếp tục; không xin lại vô cớ. Chỉ kiểm tra/cài skill không
  cho phép bắt đầu ghi âm. Cài dependency, tải model, thay quyền hệ thống,
  gửi nội dung ra ngoài cần quyền tương ứng. Script không cài/tải gì.
- Thử khoảng 30 giây trước. Kiểm tra file đã đóng, thời lượng/mức tín hiệu,
  kết quả nhận dạng tiếng Việt và đối chiếu slide. Preflight thành công
  không có nghĩa đã nghe. Silence được giữ là im lặng, không thêm lời.
- Khi đoạn thử đạt, dùng thư mục mới để thu tiếp có thời hạn. CPU mặc định;
  chỉ chọn GPU khi hỗ trợ thật. Theo dõi hiệu năng: nếu ba đoạn đang chờ/chạy,
  helper ngừng thu thêm, đóng đoạn cuối và xử lý phần còn lại. Đánh dấu
  khoảng sau lúc dừng. Không gọi đó là theo dõi liên tục.
- Khi pause/rời lớp/yêu cầu dừng/nguồn mất: tạo `STOP` trong output của
  `listen_linux.py`, đọc trạng thái và xác minh recorder đã thoát. STOP
  ở thư mục nhận dạng con không dừng recorder cha. Không tự vào lại lớp.
  Script dừng tác vụ con của nó, giữ audio và trả các luồng về sink trước
  đó khi còn hợp lệ; chỉ gỡ module tự tạo. Nếu cleanup lỗi, ghi rõ tài
  nguyên còn lại trong trạng thái, không tuyên bố đã khôi phục hoàn toàn.

Với file hợp lệ đã được cung cấp, dùng `scripts/transcribe_file.py`, không
cần quyền thu trực tiếp, không đổi định tuyến. Giữ file gốc chỉ đọc.

## Một vòng ghi bài

Đọc [references/notes-and-state.md](references/notes-and-state.md) khi tạo,
ghi tiếp, xem bù hoặc bàn giao. Các ví dụ caption trong tài liệu là tình
huống quyết định, không giả định Linux có Chrome Live Caption tiếng Việt.

1. Ghi mốc và nguồn đang đọc được. Với caption ngắn, kiểm tra theo đoạn
   khoảng 15–25 giây tùy tốc độ nói. Với audio, đọc từng đoạn đã nhận dạng.
2. Đối chiếu lời mới với slide/demo. Xác định người nói chỉ khi có bằng
   chứng: Whisper không tự phân vai. Phân biệt lời thầy, học viên, slide và
   clip demo đang phát. Không có công cụ nhìn slide thì ghi thiếu phần hình.
3. Chụp ảnh khi thay slide hoặc có thao tác/kết quả cần giữ; lưu ảnh thật,
   đúng mốc. Cùng slide nhưng có lời mới vẫn ghi tiếp. Không lấy ảnh minh
   họa tự tạo thay demo thật.
4. Ghi và lưu ngay theo trình tự. Với mỗi ví dụ giữ người trình bày, bối
   cảnh, mục tiêu, đầu vào, câu giao việc đọc được, thao tác, phản hồi,
   lỗi, lần sửa, thử tiếp và kết quả. Chưa thấy thì ghi “Chưa thấy nêu” hoặc
   “Chưa đọc được”; không tự điền bằng kiến thức nền.
5. Giữ đủ diễn biến để học lại, không nén demo nhiều phút thành vài ý kết
   luận. Được dùng lời riêng trung thành và chỉnh dấu câu; không thêm số
   liệu, lời khuyên, ví dụ, prompt hay quan hệ nhân quả ngoài nguồn. Chỉ
   dùng ngoặc kép khi đọc được đúng câu. Kết quả được kể phải ghi “Theo
   lời …”, phân biệt với kết quả thực sự hiển thị trên màn hình.
6. So đuôi mục cũ để loại chữ đệm lặp. Sau khi tua, caption cũ có thể còn;
   không gán nó cho mốc mới. Action list chỉ gồm việc thầy thực sự giao,
   kèm tiêu chí nếu nguồn có nêu. Áp dụng riêng do agent đề xuất chỉ làm
   khi được yêu cầu, tách thành tài liệu khác.
7. Cập nhật sổ trạng thái, khoảng thiếu và điểm ghi cuối. Tiếp tục vòng.

## Mốc và phần thiếu

- SRT có mốc tương đối trong từng file. `segments.csv` và ledger cho offset
  trong timeline audio của lần thu; không coi đó là timecode video. Mốc
  khởi chạy tiến trình có buffering, chưa phải lúc chính xác từng câu nói.
- Lưu `observed_intervals` (đã quan sát), `covered_intervals` (đã ghi đủ
  nguồn cần thiết), `gaps` (thiếu gì, đầu/cuối, độ chắc mốc, lý do) riêng.
  Hai ảnh cùng slide không chứng minh đoạn giữa đủ lời. Audio thu từ bây
  giờ không khôi phục đoạn trước đó.
- File trạng thái gồm nguồn bài, HTML, mode, điểm video gần nhất nếu biết,
  mục/ảnh cuối, thời điểm cập nhật, caption_status, audio_source,
  recording_active, capture_ledger, last_processed_audio_chunk,
  recognition_status, technical_attempts, complete. Không chứa token/cookie.
- Xem bù đúng khoảng thiếu và chút ngữ cảnh cần thiết; chỉ đóng khoảng sau
  khi thật sự bổ sung, đối chiếu. Không hứa tiếp tục quan sát khi lượt đã
  kết thúc; thu tự động không đồng nghĩa ghi chú đã đọc và cập nhật.

## Bàn giao

HTML dễ đọc trên điện thoại, mục lục liên kết đúng, ID duy nhất, ảnh nhúng
offline nếu lưu được. Kiểm tra thẻ/ảnh, không trùng replay, giữ nội dung cũ
và sao lưu trước sửa lớn. Hình thức đẹp không chứng minh nội dung đủ.
Chỉ gọi hoàn thành toàn bài khi đối chiếu từ đầu đến cuối và không còn
phần lời/slide cần khôi phục. Nếu thiếu, bàn giao file có thể bấm cùng
danh sách thiếu. Khi không thể tự làm một bước, nêu quan sát thật và đúng
quyền/thao tác thiếu; không yêu cầu người dùng làm lại phần đã có.

Không tự mời bot, gửi yêu cầu host, bật cloud recording, nhắn lớp, phát sinh
phí hoặc tải bài bị chặn. Audio/TXT/SRT/nhật ký ở máy, không tự gửi dịch vụ
ngoài. Không đóng gói bài học cá nhân, model hoặc bí mật vào skill công khai.
