---
name: ghi-chep-bai-hoc-linux
description: Hermes trên Linux tự xem bản ghi lớp học, lưu toàn bộ transcript rồi tóm tắt lớp học. Được phát/dừng, tua, đổi tốc độ và mở lại bài để bổ sung phần thiếu; nhận dạng file hoặc thu tiếng trình phát qua PulseAudio/PipeWire, Whisper.cpp và Silero VAD.
---

# Ghi chép bài học trên Linux

Skill độc lập cho Hermes, không cần skill Codex hoặc helper macOS. Giữ tên
`ghi-chep-bai-hoc-linux`, không ghi đè skill `ghi-chep-bai-hoc` cũ.
Mặc định **tự xem bản ghi**, không xem live cùng người dùng.

## Đầu ra: transcript trước, tóm tắt sau

Mỗi lớp một thư mục riêng trong workspace được phép:

1. `transcript-toan-bai.txt`: toàn bộ lời nhận dạng theo trình tự bản ghi,
   không nén thành ý chính. Lưu tăng dần, giữ nguyên TXT/SRT từng đoạn máy
   tạo làm nguồn đối chiếu. Chỉ tạo `transcript-toan-bai.srt` nếu đã đối
   chiếu được mốc về bản gốc; nếu chưa, giữ SRT từng đoạn và bảng offset,
   đánh dấu mốc ước lượng. Không khẳng định chữ máy chính xác từng từ.
2. `trang-thai.json`: nguồn, tiến độ, chỉ mục đoạn, bản đồ playback và
   phần thiếu để tiếp tục, kiểm tra độ đầy đủ.
3. `tom-tat-lop-hoc.html`: tạo sau khi lưu/đối chiếu transcript; tiếng Việt,
   mục lục, liên kết transcript, mốc chương, nội dung chính, các bước thầy
   dạy, ví dụ quan trọng, kết luận và bài tập thật được giao. Không tự thêm
   lời khuyên hoặc ứng dụng riêng. Ảnh slide/demo thật nếu truy cập được.

Không thay transcript bằng tóm tắt. Nếu còn thiếu, đầu transcript ghi
“CHƯA ĐẦY ĐỦ”, trạng thái nêu khoảng thiếu; tóm tắt tạm cũng ghi phạm vi
đó. Chỉ gọi bản cuối đầy đủ sau khi đối chiếu từ đầu đến cuối. Khả năng
đọc slide và chất lượng nhận dạng phải báo riêng. Script không tự đọc màn
hình, ghép transcript toàn bài hay viết tóm tắt; Hermes phải thực hiện.

## Nhận việc và chọn nguồn

1. Đọc yêu cầu hiện tại, file cũ, sổ trạng thái. Xác định đúng buổi, URL,
   ứng dụng, thời lượng nếu đọc được, vị trí và nơi lưu. Tạo transcript và
   trạng thái ngay; không trộn buổi, không sửa `sources/`.
2. Dùng công cụ Hermes thực sự có, không gọi API Codex/CUA tưởng tượng.
   Truy cập bình thường trong tài khoản được phép, không lấy URL media ẩn,
   vượt chặn tải/ghi, mượn tài khoản hoặc mời bot dự lớp.
3. Có file audio/video cục bộ được cung cấp hợp lệ: ưu tiên nhận dạng trực
   tiếp bằng `scripts/transcribe_file.py`; không phát nhanh rồi thu lại.
   File gốc chỉ đọc. Nếu file quá dài cho tài nguyên/timeout, chia bản sao
   audio thành các đoạn có offset gốc đã lưu, không âm thầm bỏ phần cuối.
4. Chỉ xem được trên player: đọc caption nếu dùng được hoặc thu âm thanh
   của đúng luồng bài học. Nếu đã chọn nghe cục bộ, đi thẳng kiểm tra audio,
   không bắt thử caption lại. Caption lỗi thì chuyển đường nghe sau kiểm
   tra có ý nghĩa; tiếp tục slide, đánh dấu thiếu, không lặp thao tác mãi.

## Tự điều khiển bản ghi — chế độ mặc định

- Lưu `mode=recorded_review`. Được phát/dừng, tua tới/lùi, đổi tốc độ và
  mở lại bài/trang/player trong phạm vi truy cập đã có để xử lý đủ. Không
  xin lại quyền điều khiển mỗi lần. Mở bản ghi khác với tự Join họp live.
- Bắt đầu đoạn thử có lời ở 1×. Chỉ tăng tốc sau khi đối chiếu nhận dạng
  tiếng Việt, tên/số liệu và khả năng theo demo; giảm về 1× ở đoạn khó.
  Không mặc định một mức tốc độ cao luôn nhận dạng tốt.
- Được tua tìm chương, xem lại đoạn chưa rõ và mở lại sau gián đoạn. Đoạn
  nhảy qua vẫn chưa xử lý, phải quay lại trước khi gọi đủ toàn bài. Không
  bỏ đoạn chỉ vì ít chữ hoặc slide không thay đổi.
- Pause do Hermes để ghi/đợi nhận dạng là thao tác nội bộ: lưu mốc, dừng
  lượt thu, xử lý rồi được tiếp tục trong nhiệm vụ. Người dùng yêu cầu
  pause/dừng là lệnh dừng nhiệm vụ: dừng thu và chờ người dùng tiếp tục.
- Trước khi tua/đổi tốc độ/mở lại, dừng lượt thu, xác minh đã dừng và lưu
  vị trí player đọc được. Sau thao tác kiểm tra vị trí/tốc độ thật, không
  lấy chữ caption cũ; dùng output mới và xác minh lại luồng khi thu tiếp.
  Không xóa STOP để tái dùng output, không tự tiếp tục sau STOP của người dùng.
- Lưu bảng ánh xạ từng lượt: đoạn nguồn, video_start/video_end nếu đọc
  được, playback_rate, audio_offset và độ chắc mốc. Không coi 30 giây audio
  ở 2× là 30 giây của video gốc. Công thức video_start + audio_offset × rate
  chỉ là ước tính khi có bằng chứng phát liên tục, tốc độ cố định, không
  buffering; phải so mốc player. Không đủ bằng chứng thì đánh dấu chưa khớp.
- Ghép lời theo thứ tự bản ghi, không theo thứ tự tua/xem. Đối chiếu vùng
  xem lặp rồi hợp nhất, giữ raw. Không xóa câu thầy thực sự nói lặp tại mốc
  khác. Đoạn mất lời để khoảng thiếu, không suy từ slide để dựng lời nói.
- Nếu người dùng yêu cầu live/xem cùng riêng, dùng `mode=live_together`,
  giữ playback của họ; không tự vào lại lớp sau khi họ rời. Quy tắc live
  không được dùng để cấm điều khiển bản ghi trong recorded_review.

## Nghe cục bộ trên Linux

Đọc [references/linux-audio.md](references/linux-audio.md) trước khi thu,
định tuyến hoặc xử lý sự cố. Live capture ở đây là thu tiếng player đang
phát, không nhất thiết là lớp trực tiếp. Hỗ trợ PulseAudio hoặc PipeWire
có pipewire-pulse/pactl JSON. PipeWire thuần chưa có backend đi kèm.

- Hermes phải kết nối được audio server của phiên đang phát bài. Cùng máy
  nhưng service/container/SSH chưa chứng minh có quyền; máy chủ Linux
  khác không tự nghe được bài đang phát trên Mac.
- Kiểm tra chỉ đọc trước. Xác minh sink-input từ app/PID và bài thật;
  không tái dùng ID cũ, không hứa tách một tab chỉ bằng tên/PID Chrome.
- Script tạo sink riêng, chuyển đúng luồng được chọn, thu monitor riêng;
  không mic, hình, default source hoặc monitor loa chung. Nếu nguồn đổi,
  mất hoặc luồng khác vào sink riêng thì dừng. Có độ trễ kiểm tra, không
  hứa cách ly tuyệt đối hoặc không mất mẫu. Không thử bằng nguồn riêng tư khác.
- Đọc quyền đã có và tiếp tục đúng phạm vi, không xin lại vô cớ. Cài skill
  không tự cho phép thu. Cài dependency/tải model/đổi quyền cần quyền
  tương ứng; helper không cài/tải gì hoặc gọi mạng. Không gửi nội dung ra ngoài.
- Thử 30 giây ở 1×, đọc file đã đóng, thời lượng/mức tín hiệu, chữ tiếng
  Việt và đối chiếu nguồn. Preflight không chứng minh nghe được. Silence
  giữ là im lặng, không thêm lời. Với file mode không thử recorder không cần thiết.
- Thu tiếp bằng output mới, thời hạn rõ. CPU mặc định, GPU sau khi kiểm tra.
  Ba đoạn nhận dạng đang chờ/chạy thì helper dừng recorder, đóng đoạn cuối
  và xử lý phần còn lại. Trong recorded_review, dừng player, đọc phần đã
  lưu, ghi khoảng thiếu rồi quay về mốc chưa xử lý để tiếp tục bằng output
  mới; không gọi đó là thu liên tục hoặc tự xóa STOP của người dùng.
- Khi cần đổi playback, nguồn mất hoặc người dùng yêu cầu dừng: tạo STOP
  ở output gốc listen_linux.py, kiểm tra recorder đã thoát. STOP ở thư mục
  nhận dạng con không dừng recorder cha. Dừng chỉ tác vụ con do mình tạo,
  giữ audio; trả luồng về sink gốc nếu còn hợp lệ, chỉ gỡ module tự tạo.
  Đọc cleanup_issues, không tuyên bố khôi phục hết khi còn lỗi.

## Chép lời và tóm tắt

Đọc [references/notes-and-state.md](references/notes-and-state.md) khi ghép
transcript, xem bù, tóm tắt hoặc bàn giao.

1. Đọc đoạn nhận dạng mới, lưu raw TXT/SRT và mốc nguồn trước khi làm việc
   khác. Đối chiếu slide/demo bằng công cụ hiện có; không nhìn được thì
   ghi thiếu hình. Whisper không tự phân vai người nói.
2. Giữ toàn bộ lời đọc được: ví dụ, câu giao việc, thao tác được nói tới,
   lỗi, lần sửa và phản hồi. Không viết lại thành lời riêng hoặc rút ý ở
   transcript. Bản đọc có thể chỉnh dấu câu/lỗi nhận dạng đã đối chiếu;
   raw vẫn nguyên, chỗ chưa chắc được gắn nhãn. Không đoán tên/số liệu.
3. Phân biệt người nói khi có bằng chứng, nếu chưa ghi “Người nói chưa xác
   định”. Chữ trên slide, thao tác không lời và nhận xét agent phải tách
   khỏi transcript lời nói. Lời kể không thành kết quả agent đã kiểm chứng.
4. Ghép đúng timeline gốc và loại trùng do replay bằng mốc+nội dung, không
   chỉ dựa câu giống nhau. Cập nhật phạm vi đã xử lý, phần thiếu và điểm
   cuối. Quay lại đoạn thiếu để khôi phục trong phạm vi nhiệm vụ.
5. Sau khi lưu và kiểm tra toàn bộ transcript, viết HTML tóm tắt riêng.
   Tóm tắt được diễn đạt lại trung thành, dẫn mốc/chương; giữ điều kiện
   quan trọng, các bước cần thực hành và lần sửa làm thay đổi kết quả.
   Action list chỉ là việc thầy thực sự giao. Không tự tạo bài tập/tiêu chí.
6. Nếu nhiệm vụ bị gián đoạn, lưu transcript hiện có và trạng thái. Nếu
   bàn giao tóm tắt tạm thì nêu rõ giới hạn; không coi đoạn chưa xử lý là
   hoàn thành. Không hứa làm tiếp sau khi lượt chat đã ngừng.

## Nghiệm thu và bàn giao

- Đối chiếu toàn phạm vi được giao, khoảng chưa xử lý, độ rõ tên/số liệu và
  khả năng đối chiếu hình. Video ended=true không chứng minh transcript đủ.
- Sổ trạng thái có transcript_path, raw_sources, playback_sessions,
  transcript_complete, summary_path, summary_status, gaps và các trường
  nguồn/tiến độ trong tài liệu đi kèm. Không chứa token/cookie.
- Kiểm tra transcript thực sự có nội dung đầy đủ đã xử lý, tóm tắt dẫn
  đúng nguồn, HTML đọc được trên điện thoại, mục lục/ảnh/ID đúng. Giữ nội
  dung cũ và sao lưu trước sửa lớn. Hình thức đẹp không chứng minh đủ lời.
- Bàn giao link transcript TXT, raw/SRT tổng nếu khớp mốc, trạng thái và
  HTML tóm tắt; nêu phần thiếu và mức kiểm chứng. Hoàn thành nhiệm vụ gồm
  lưu cả hai đầu ra và dừng tác vụ/khôi phục audio nếu có.

Không tự nhắn lớp/host, bật cloud recording, mời bot, phát sinh phí hoặc
vượt chặn nội dung. Không đóng gói bài học, model hoặc bí mật vào skill công khai.
